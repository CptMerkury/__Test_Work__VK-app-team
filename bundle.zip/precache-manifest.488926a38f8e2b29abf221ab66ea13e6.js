self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f60def9436d41cfa71f379e347896aa6",
    "url": "./index.html"
  },
  {
    "revision": "e3eb5585d4b8762d9640",
    "url": "./static/css/2.8fde3e13.chunk.css"
  },
  {
    "revision": "e3eb5585d4b8762d9640",
    "url": "./static/js/2.dbe0a63a.chunk.js"
  },
  {
    "revision": "570d362d673dab785e62d2b8563e1118",
    "url": "./static/js/2.dbe0a63a.chunk.js.LICENSE.txt"
  },
  {
    "revision": "fc892ded71aa996ba77b",
    "url": "./static/js/main.70735192.chunk.js"
  },
  {
    "revision": "558e029f9e4335804554",
    "url": "./static/js/runtime-main.6706c871.js"
  }
]);